# Tic Tac Toe



A simple, but still the ultimate, Tic Tac Toe app
Now, why does it need a readme? Well, the better question is; Why Not!


For instance, part of the About the Authors, or part of the code, or part of the part of!