To contribute:

Make your additions in a seperate branch
Update branch to match main often, to ensure it's always compatible with other updates
Once done with it, confirm with other team members, and submit